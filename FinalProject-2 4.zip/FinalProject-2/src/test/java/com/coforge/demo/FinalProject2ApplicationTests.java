package com.coforge.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalProject2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
