package com.coforge.demo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coforge.demo.Entity.BusDetails;
import com.coforge.demo.Repository.BusDetailsRepository;

import jakarta.transaction.Transactional;

@Service
public class BusDetailsService {

    @Autowired
    private BusDetailsRepository repository;

    public String addBusDetails(BusDetails busDetails) {
        if (repository.existsByBusNo(busDetails.getBusNo())) {
            return "Bus details already exist!";
        } else {
            repository.save(busDetails);
            return "Bus details added successfully!";
        }
    }

    public String updateBusDetails(Long busNo, BusDetails busDetails) {
        BusDetails existingBusDetails = repository.findByBusNo(busNo);
        if (existingBusDetails != null) {
            BusDetails updatedBusDetails = existingBusDetails;
            updatedBusDetails.setBusNo(busDetails.getBusNo());
            updatedBusDetails.setMovement(busDetails.getMovement());
            updatedBusDetails.setSource(busDetails.getSource());
            updatedBusDetails.setDestination(busDetails.getDestination());
            updatedBusDetails.setDepartDate(busDetails.getDepartDate());
            updatedBusDetails.setDepartTime(busDetails.getDepartTime());
            updatedBusDetails.setPrice(busDetails.getPrice());
            updatedBusDetails.setSeat(busDetails.getSeat());
            repository.save(updatedBusDetails);
            return "Bus details updated successfully!";
        } else {
            return "Bus details not found!";
        }
    }

    public List<BusDetails> getAllBusDetails() {
        return repository.findAll();
    }
    @Transactional
    public String deleteBusDetails(Long busNo) {
        if (repository.existsByBusNo(busNo)) {
            repository.deleteByBusNo(busNo);
            return "Bus details deleted successfully!";
        } else {
            return "Bus details not found!";
        }
    }
    public List<BusDetails> findBuses(String source, String destination) {
        return repository.findBySourceAndDestination(source, destination);
    }

	
   
   

  
    

    }

    