package com.coforge.demo.Controller;


import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.coforge.demo.Entity.BusDetails;
import com.coforge.demo.Repository.BusDetailsRepository;
import com.coforge.demo.Service.BusDetailsService;

@Controller
@RequestMapping("/admin")
public class BusDetailsController {
	
	@Autowired
    private BusDetailsRepository repository;

    @Autowired
    private BusDetailsService service;

    @GetMapping("/dashboard")
    public String showDashboard(Model model) {
        model.addAttribute("message", "Admin");
        return "adminDashboard";
    }

    @PostMapping("/addBusDetails")
    public String addBusDetails(@RequestParam Long busNo, @RequestParam String movement,
                                @RequestParam String source, @RequestParam String destination,
                                @RequestParam String departDate, @RequestParam String departTime,
                                @RequestParam Double price, @RequestParam Integer seat, Model model) {
        BusDetails busDetails = new BusDetails();
        busDetails.setBusNo(busNo);
        busDetails.setMovement(movement);
        busDetails.setSource(source);
        busDetails.setDestination(destination);
        busDetails.setDepartDate(Date.valueOf(departDate));
        busDetails.setDepartTime(departTime);
        busDetails.setPrice(price);
        busDetails.setSeat(seat);

        String message = service.addBusDetails(busDetails);
        model.addAttribute("message", message);
        return "redirect:/admin/dashboard";
    }

    @GetMapping("/allBuses")
    public String getAllBuses(Model model) {
        List<BusDetails> buses = service.getAllBusDetails();
        buses.forEach(bus -> System.out.println("bus number:"+bus.getBusNo())); // Print bus numbers to console
        
        model.addAttribute("buses", buses);
        return "allBuses";
    }

    @PostMapping("/deleteBus")
    public String deleteBus(@RequestParam Long busNo, Model model) {
        String message = service.deleteBusDetails(busNo);
        model.addAttribute("message", message);
        return "redirect:/admin/allBuses";
    }
    @GetMapping("/updateBus")
    public String showUpdateForm(@RequestParam Long busNo, Model model) {
        BusDetails busDetails = repository.findByBusNo(busNo);
        model.addAttribute("busDetails", busDetails);
        return "updateBusForm"; // Points to /WEB-INF/jsp/updateBusForm.jsp
    }

    @PostMapping("/updateBusDetails")
    public String updateBusDetails(@RequestParam Long busNo, @RequestParam String movement,
                                   @RequestParam String source, @RequestParam String destination,
                                   @RequestParam String departDate, @RequestParam String departTime,
                                   @RequestParam Double price, @RequestParam Integer seat, Model model) {
        BusDetails busDetails = new BusDetails();
        busDetails.setBusNo(busNo);
        busDetails.setMovement(movement);
        busDetails.setSource(source);
        busDetails.setDestination(destination);
        busDetails.setDepartDate(Date.valueOf(departDate));
        busDetails.setDepartTime(departTime);
        busDetails.setPrice(price);
        busDetails.setSeat(seat);

        String message = service.updateBusDetails(busNo, busDetails);
        model.addAttribute("message", message);
        return "redirect:/admin/allBuses";
    }
}
