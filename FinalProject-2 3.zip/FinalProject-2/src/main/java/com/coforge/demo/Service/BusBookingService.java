package com.coforge.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coforge.demo.Entity.Booking;
import com.coforge.demo.Entity.BusDetails;
import com.coforge.demo.Repository.BookingRepository;
import com.coforge.demo.Repository.BusDetailsRepository;
@Service
public class BusBookingService {

	    @Autowired
	    private BookingRepository bookingRepository;
	    
	    public List<Booking> findBookingsByEmail(String email) {
	        return bookingRepository.findBookingsByEmail(email);
	    }

		 public Booking findBusById(Long busId) {
        return bookingRepository.findById(busId).orElse(null);
    }

		public void saveBooking(Booking booking) {
			// TODO Auto-generated method stub
			bookingRepository.save(booking);
		}
		
	}


