package com.coforge.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.coforge.demo.Entity.Booking;
import com.coforge.demo.Entity.BusDetails;
import com.coforge.demo.Service.BusBookingService;
import com.coforge.demo.Service.BusDetailsService;

import jakarta.servlet.http.HttpSession;

@Controller
public class BusBookingController {
    @Autowired
    private BusDetailsService busService;

    @Autowired
    private BusBookingService busService1;

    @GetMapping("/search")
    public String searchBuses() {
        return "searchBuses";
    }

    @PostMapping("/searchResults")
    public String searchResults(@RequestParam String source, @RequestParam String destination, Model model, HttpSession session) {
        List<BusDetails> buses = busService.findBuses(source, destination);
        model.addAttribute("buses", buses);
        model.addAttribute("source", source);
        model.addAttribute("destination", destination);

        // Store source and destination in the session
        session.setAttribute("source", source);
        session.setAttribute("destination", destination);

        buses.forEach(bus -> System.out.println("bus number:" + bus.getBusNo()));
        return "searchResults";
    }

    @GetMapping("/selectBus")
    public String selectBus(@RequestParam Long busNo, HttpSession session) {
        // Store the selected bus ID in the session
        session.setAttribute("selectedBusId", busNo);
        System.out.println("Selected Bus ID stored in session: " + busNo);
        return "redirect:/login";
    }

    @GetMapping("/bookBus")
    public String bookBus(Model model, HttpSession session) {


        // Retrieve the selected bus ID from the session
        Long busId = (Long) session.getAttribute("selectedBusId");
        System.out.println("Retrieved Bus ID from session: " + busId);
        if (busId == null) {
            return "redirect:/search"; // Redirect to search if no bus is selected
        }

        // Retrieve source and destination from the session
        String source = (String) session.getAttribute("source");
        String destination = (String) session.getAttribute("destination");
        System.out.println(source + " " + destination);
        model.addAttribute("source", source);
        model.addAttribute("destination", destination);

        return "bookingForm";
    }
    @PostMapping("/confirmBooking")
    public String confirmBooking(@RequestParam String name, @RequestParam String dateOfJourney,
                                 @RequestParam String time, @RequestParam Integer numberOfSeats,
                                 Model model, HttpSession session) {
    	 String email = (String) session.getAttribute("user");
         if (email == null) {
             return "redirect:/login";
         }

         // Retrieve the selected bus ID from the session
         Long busId = (Long) session.getAttribute("selectedBusId");
          System.out.println(busId);
        // Fetch bus details from the database
        BusDetails bus = busService.findbyBusNo(busId);
        double pricePerSeat = bus.getPrice();
        double totalCost = pricePerSeat * numberOfSeats;
        bus.setSeat(bus.getSeat() -numberOfSeats);
        // Create a new booking
        Booking booking = new Booking();
        booking.setBusId(busId);
       // booking.setEmail(email);
        booking.setName(name);
        booking.setDateOfJourney(dateOfJourney);
        booking.setTime(time);
        booking.setNumberOfSeats(numberOfSeats);
        
        booking.setTotalCost(totalCost);

        // Save the booking
        busService1.saveBooking(booking);

        // Add booking details to the model
        model.addAttribute("busId", busId);
        model.addAttribute("name", name);
        model.addAttribute("dateOfJourney", dateOfJourney);
        model.addAttribute("time", time);
        model.addAttribute("numberOfSeats", numberOfSeats);
        model.addAttribute("totalCost", totalCost);
      //  model.addAttribute("email", email);
        // Clear the session to require login for the next booking
        session.invalidate();
        return "bookingConfirmation";
    }

    @GetMapping("/bookingHistory")
    public String bookingHistory(Model model, HttpSession session) {
        // Retrieve the user email from the session
        String email = (String) session.getAttribute("user");

        // Fetch booking history for the user
        List<Booking> bookings = busService1.findBookingsByEmail(email);
        model.addAttribute("bookings", bookings);

        return "bookingHistory";
    }}