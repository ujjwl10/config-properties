package com.coforge.demo.Entity;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "bus_details")
public class BusDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "bus_no", nullable = false)
    private Long busNo;

    @Column(name = "movement", nullable = false)
    private String movement;

    @Column(name = "source", nullable = false)
    private String source;

    @Column(name = "destination", nullable = false)
    private String destination;

    @Column(name = "depart_date", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date departDate;

    @Column(name = "depart_time", nullable = false)
    private String departTime;

    @Column(name = "price", nullable = false)
    private Double price;

    @Column(name = "seat", nullable = false)
    private Integer seat;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getBusNo() {
		return busNo;
	}

	public void setBusNo(Long busNo) {
		this.busNo = busNo;
	}

	public String getMovement() {
		return movement;
	}

	public void setMovement(String movement) {
		this.movement = movement;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Date getDepartDate() {
		return departDate;
	}

	public void setDepartDate(Date departDate) {
		this.departDate = departDate;
	}

	public String getDepartTime() {
		return departTime;
	}

	public void setDepartTime(String departTime) {
		this.departTime = departTime;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Integer getSeat() {
		return seat;
	}

	public void setSeat(Integer seat) {
		this.seat = seat;
	}

	

	

    
}
