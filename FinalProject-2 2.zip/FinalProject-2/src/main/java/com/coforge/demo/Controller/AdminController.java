package com.coforge.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


import com.coforge.demo.Service.AdminService;

@Controller
public class AdminController {
    @Autowired
    private AdminService adminService;

    @GetMapping("/admin/login")
    public String adminLoginPage() {
        return "adminLogin";
    }

    @PostMapping("/admin/login")
    public String processLogin(@RequestParam String employeeId,
            @RequestParam String password, 
            Model model) {
// Validate user credentials
if (adminService.validateAdmin(employeeId, password)) {
model.addAttribute("message" + employeeId);
return "adminDashboard"; // Points to /WEB-INF/jsp/dashboard.jsp
} else {
model.addAttribute("error", "Invalid EmployeeId or Password");
return "adminLogin"; // Points to /WEB-INF/jsp/login.jsp
}
}

    @GetMapping("/admin/create")
    public String createAdminPage() {
        return "createAdmin";
    }
    @PostMapping("/admin/create")
    public String createAccount(@RequestParam String employeeId, 
                               @RequestParam String password, 
                                Model model) {
        // Handle account creation via the service layer
        if (adminService.createAccount(employeeId, password)) {
            model.addAttribute("message", "Account created successfully!");
            return "adminLogin"; // Redirect to login page
        } else {
            model.addAttribute("error", "Username already exists!");
            return "createAdmin"; // Stay on the create account page
        }
    }
 
}

