package com.coforge.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.coforge.demo.Entity.user;
import com.coforge.demo.Service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class UserController {
    @Autowired
    private UserService userService;

    // Login page
    @GetMapping("/login")
    public String loginPage() {
        return "login"; // Points to /WEB-INF/jsp/login.jsp
    }

    // Process login attempt
    @PostMapping("/login")
    public String processLogin(@RequestParam String email,
                               @RequestParam String password, 
                               Model model) {
        // Validate user credentials
    	
        if (userService.validateUser(email, password)) {
            model.addAttribute("message", "Welcome, " + email );
            return "dashboard"; // Points to /WEB-INF/jsp/dashboard.jsp
        } else {
            model.addAttribute("error", "Invalid Username or Password");
            return "login"; // Points to /WEB-INF/jsp/login.jsp
        }
    }

    // Create account page
    @GetMapping("/createAccount")
    public String showCreateAccountPage() {
        return "createAccount"; // Points to /WEB-INF/jsp/createAccount.jsp
    }

    // Process account creation
    @PostMapping("/createAccount")
    public String createAccount(@RequestParam String username, 
                                @RequestParam String password, 
                                @RequestParam String firstName, 
                                @RequestParam String lastName, 
                                @RequestParam String email, 
                                @RequestParam String confirmPassword, 
                                @RequestParam String contactNo, 
                                Model model) {
        // Handle account creation via the service layer
        if (userService.createAccount(username, password, firstName, lastName, email, confirmPassword, contactNo, model)) {
            model.addAttribute("message", "Account created successfully!");
            return "login"; // Redirect to login page
        } else {
            // Error messages are now handled within the service layer and passed to the model
            return "createAccount"; // Stay on the create account page
        }
    }

    // Show forgot password page
    @GetMapping("/forgot-password")
    public String showForgotPasswordPage() {
        return "forgot-password"; // Points to /WEB-INF/jsp/forgot-password.jsp
    }

    // Process password reset
    @PostMapping("/forgot-password")
    public String resetPassword(@RequestParam String email, @RequestParam String newPassword, Model model) {
        String result = userService.resetPassword(email, newPassword);
        model.addAttribute("message", result);
        return "forgot-password"; // Show the same forgot-password page with a success message
    }
}
