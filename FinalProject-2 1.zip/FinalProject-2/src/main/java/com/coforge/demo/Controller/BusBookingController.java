package com.coforge.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.coforge.demo.Entity.BusDetails;
import com.coforge.demo.Service.BusDetailsService;

import jakarta.servlet.http.HttpSession;

@Controller
public class BusBookingController {
    @Autowired
    private BusDetailsService busService;

    @GetMapping("/search")
    public String searchBuses() {
        return "searchBuses";
    }

    @PostMapping("/searchResults")
    public String searchResults(@RequestParam String source, @RequestParam String destination, Model model) {
        List<BusDetails> buses = busService.findBuses(source, destination);
        model.addAttribute("buses", buses);
        model.addAttribute("source", source);
        model.addAttribute("destination", destination);
        
        // Print bus numbers
        printBusNumbers(buses);
        
        return "searchBuses";
    }

    private void printBusNumbers(List<BusDetails> buses) {
		
    	 for (BusDetails bus : buses) {
             System.out.println("Bus Number: " + bus.getBusNo() + ", Number of Seats: " + bus.getSeat());
         }
		
	}

//    @GetMapping("/book")
//    public String bookBus(@RequestParam Long busId, Model model, HttpSession session) {
//        // Check if user is logged in
//        if (session.getAttribute("user") == null) {
//            // Store the busId in session to use after login
//            session.setAttribute("busId", busId);
//            return "redirect:/login";
//        }
//
//        // If user is logged in, redirect to booking form page
//        model.addAttribute("busId", busId);
//        return "bookingForm";
//    }
//
//    @PostMapping("/confirmBooking")
//    public String confirmBooking(@RequestParam Long busId, @RequestParam String name, @RequestParam Integer seatNumber,
//                                 @RequestParam String dateOfJourney, @RequestParam String time, @RequestParam Integer numberOfSeats, Model model) {
//        // Calculate the cost of booking (example: price per seat is 500)
//        double pricePerSeat = 500.0;
//        double totalCost = pricePerSeat * numberOfSeats;
//
//        // Add booking details to the model
//        model.addAttribute("busId", busId);
//        model.addAttribute("name", name);
//        model.addAttribute("seatNumber", seatNumber);
//        model.addAttribute("dateOfJourney", dateOfJourney);
//        model.addAttribute("time", time);
//        model.addAttribute("numberOfSeats", numberOfSeats);
//        model.addAttribute("totalCost", totalCost);
//
//        return "bookingConfirmation";
//    }

   
}