package com.coforge.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.coforge.demo.Entity.Admin;
import com.coforge.demo.Repository.AdminRepository;

@Service
public class AdminService {
	 @Autowired
	    private AdminRepository adminRepository;

	    // Validate user credentials
	    public boolean validateAdmin(String employeeId, String password) {
	        return adminRepository.findByEmployeeIdAndPassword(employeeId, password).isPresent();
	    }

	    // Create a new user account
	    public boolean createAccount(String employeeId, String password) {
	        if (adminRepository.findByemployeeId(employeeId).isPresent()) {
	            return false; // employee id already exists
	        } else {
	            Admin a1 = new Admin();
	            a1.seteId(employeeId);
	            a1.setPassword(password);
	            adminRepository.save(a1);
	            return true;
	        }
	    }
}
