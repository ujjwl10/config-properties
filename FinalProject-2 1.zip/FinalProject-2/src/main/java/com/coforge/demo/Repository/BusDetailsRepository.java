package com.coforge.demo.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.coforge.demo.Entity.BusDetails;

public interface BusDetailsRepository extends JpaRepository<BusDetails, Long>{
	boolean existsByBusNo(String busNo);
	List<BusDetails> findBySourceAndDestination(String source, String destination);
	 void deleteByBusNo(String busNo);
	
}
