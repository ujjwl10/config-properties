package com.coforge.demo.Controller;

import java.sql.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.coforge.demo.Entity.BusDetails;
import com.coforge.demo.Repository.BusDetailsRepository;
import com.coforge.demo.Service.BusDetailsService;

@Controller
@RequestMapping("/admin")
public class BusDetailsController {
    
    @Autowired
    private BusDetailsRepository repository;

    @Autowired
    private BusDetailsService service;

    @GetMapping("/dashboard")
    public ResponseEntity<String> showDashboard() {
        return ResponseEntity.ok("Admin Dashboard");
    }

    @PostMapping("/addBusDetails")
    public ResponseEntity<String> addBusDetails(@RequestBody BusDetails busDetails) {
        String message = service.addBusDetails(busDetails);
        return ResponseEntity.status(HttpStatus.CREATED).body(message);
    }

    @GetMapping("/allBuses")
    public ResponseEntity<List<BusDetails>> getAllBuses() {
        List<BusDetails> buses = service.getAllBusDetails();
        buses.forEach(bus -> System.out.println("bus number:" + bus.getBusNo())); // Print bus numbers to console
        return ResponseEntity.ok(buses);
    }

    @PostMapping("/deleteBus")
    public ResponseEntity<String> deleteBus(@RequestParam Long busNo) {
        String message = service.deleteBusDetails(busNo);
        return ResponseEntity.ok(message);
    }

    @GetMapping("/updateBus")
    public ResponseEntity<BusDetails> showUpdateForm(@RequestParam Long busNo) {
        BusDetails busDetails = repository.findByBusNo(busNo);
        return ResponseEntity.ok(busDetails);
    }

    @PostMapping("/updateBusDetails")
    public ResponseEntity<String> updateBusDetails(@RequestBody BusDetails busDetails) {
        String message = service.updateBusDetails(busDetails.getBusNo(), busDetails);
        return ResponseEntity.ok(message);
    }
}