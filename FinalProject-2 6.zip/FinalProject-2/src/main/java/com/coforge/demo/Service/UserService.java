package com.coforge.demo.Service;

import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coforge.demo.Entity.user;
import com.coforge.demo.Repository.UserRepository;

import jakarta.transaction.Transactional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    private static final String PASSWORD_PATTERN =
            "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$";
    private static final Pattern pattern = Pattern.compile(PASSWORD_PATTERN);

    public boolean validateUser(String email, String password) { 
        user user = userRepository.findByEmail(email).orElse(null); 
        return user != null && user.getPassword().equals(password);
    }

    // Create a new user account
    public String createAccount(String username, String password, String firstName, String lastName, 
                                 String email, String confirmPassword, String contactNo) {
        if (userRepository.findByUsername(username).isPresent()) {
            return "Username already exists!";
        } else if (userRepository.findByEmail(email).isPresent()) {
            return "Email already exists!";
        } else if (!password.equals(confirmPassword)) {
            return "Password and Confirm Password do not match!";
        } else if (!pattern.matcher(password).matches()) {
            return "Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character!";
        } else if (!contactNo.matches("^\\d{10}$")) {
            return "Contact number must be 10 digits!";
        } else {
            user newUser = new user();
            newUser.setUsername(username);
            newUser.setPassword(password); // Store the password as plain text
            newUser.setConfirmPassword(confirmPassword); // Store the confirm password as plain text
            newUser.setFirstName(firstName);
            newUser.setLastName(lastName);
            newUser.setEmail(email);
            newUser.setContactNo(contactNo);
            userRepository.save(newUser);
            return "Account created successfully!";
        }
    }

    // Reset password
    @Transactional
    public String resetPassword(String email, String newPassword) {
        user u = userRepository.findByEmail(email).orElse(null);
        if (u == null) {
            return "User not found!";
        }
        if (!pattern.matcher(newPassword).matches()) {
            return "Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character!";
        }
        u.setPassword(newPassword); // Store the password as plain text
        userRepository.save(u);
        return "Password reset successful!";
    }
}