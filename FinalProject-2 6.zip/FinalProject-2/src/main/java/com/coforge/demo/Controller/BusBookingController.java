package com.coforge.demo.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import com.coforge.demo.Entity.Booking;
import com.coforge.demo.Entity.BusDetails;
import com.coforge.demo.Repository.BusDetailsRepository;
import com.coforge.demo.Service.BusBookingService;
import com.coforge.demo.Service.BusDetailsService;
import jakarta.servlet.http.HttpSession;

@Controller
public class BusBookingController {
    @Autowired
    private BusDetailsService busService;
    
    @Autowired
    private BusBookingService busService1;
    
    @Autowired
    private BusDetailsRepository repository;

    @GetMapping("/search")
    public ResponseEntity<String> searchBuses() {
        return ResponseEntity.ok("searchBuses");
    }

    @PostMapping("/searchResults")
    public ResponseEntity<List<BusDetails>> searchResults(@RequestBody BusDetails searchRequest, HttpSession session) {
        List<BusDetails> buses = busService.findBuses(searchRequest.getSource(), searchRequest.getDestination());
        session.setAttribute("source", searchRequest.getSource());
        session.setAttribute("destination", searchRequest.getDestination());
        return ResponseEntity.ok(buses);
    }

    @GetMapping("/selectBus")
    public ResponseEntity<String> selectBus(@RequestParam Long busNo, HttpSession session) {
        session.setAttribute("selectedBusId", busNo);
        return ResponseEntity.ok("Selected Bus ID stored in session: " + busNo);
    }

    @GetMapping("/bookBus")
    public ResponseEntity<?> bookBus(HttpSession session) {
        Long busId = (Long) session.getAttribute("selectedBusId");
        if (busId == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("No bus selected");
        }

        String source = (String) session.getAttribute("source");
        String destination = (String) session.getAttribute("destination");

        BusDetails bus = repository.findByBusNo(busId);
        if (bus == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Bus not found");
        }

        return ResponseEntity.ok(bus);
    }

    @PostMapping("/confirmBooking")
    public ResponseEntity<String> confirmBooking(@RequestBody Booking bookingRequest, HttpSession session) {
        String email = (String) session.getAttribute("user");
        if (email == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not logged in");
        }

        Long busId = (Long) session.getAttribute("selectedBusId");
        if (busId == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("No bus selected");
        }

        BusDetails bus = repository.findByBusNo(busId);
        if (bus == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Bus not found");
        }

        if (bookingRequest.getNumberOfSeats() > bus.getSeat()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Number of seats requested exceeds available seats");
        }

        double totalCost = bus.getPrice() * bookingRequest.getNumberOfSeats();
        bus.setSeat(bus.getSeat() - bookingRequest.getNumberOfSeats());

        bookingRequest.setBusId(busId);
        bookingRequest.setEmail(email);
        bookingRequest.setTotalCost(totalCost);

        busService1.saveBooking(bookingRequest);

        return ResponseEntity.status(HttpStatus.CREATED).body("Booking confirmed");
    }

    @GetMapping("/bookingHistory")
    public ResponseEntity<List<Booking>> bookingHistory(HttpSession session) {
        String email = (String) session.getAttribute("user");
        if (email == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
        }

        List<Booking> bookings = busService1.findBookingsByEmail(email);
        return ResponseEntity.ok(bookings);
    }

    @PostMapping("/deleteBooking")
    public ResponseEntity<String> deleteBooking(@RequestBody Booking bookingRequest, HttpSession session) {
        String email = (String) session.getAttribute("user");
        if (email == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not logged in");
        }

        busService1.deleteBookingByBookingId(bookingRequest.getBookingId());
        return ResponseEntity.ok("Booking deleted successfully");
    }
}