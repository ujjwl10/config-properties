package com.coforge.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.coforge.demo.Entity.Admin;
import com.coforge.demo.Service.AdminService;

import jakarta.servlet.http.HttpSession;

@Controller
public class AdminController {
    @Autowired
    private AdminService adminService;

    @GetMapping("/admin/login")
    public String adminLoginPage() {
        return "adminLogin"; // Update this if using a different view technology
    }

    @PostMapping("/admin/login")
    public ResponseEntity<String> processLogin(@RequestBody Admin admin, HttpSession session) {
        // Validate user credentials
        if (adminService.validateAdmin(admin.geteId(), admin.getPassword())) {
            // Save admin information in session
            session.setAttribute("admin", admin.geteId());
            return ResponseEntity.ok("Welcome, " + "Admin");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid EmployeeId or Password");
        }
    }

    @GetMapping("/admin/create")
    public String createAdminPage() {
        return "createAdmin"; // Update this if using a different view technology
    }

    @PostMapping("/admin/create")
    public ResponseEntity<String> createAccount(@RequestBody Admin admin) {
        // Handle account creation via the service layer
        if (adminService.createAccount(admin.geteId(), admin.getPassword())) {
            return ResponseEntity.status(HttpStatus.CREATED).body("Account created successfully!");
        } else {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Username already exists!");
        }
    }

    @GetMapping("/admin/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login?logout";
    }
}