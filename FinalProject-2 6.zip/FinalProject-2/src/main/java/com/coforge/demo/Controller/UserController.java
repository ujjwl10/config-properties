package com.coforge.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.coforge.demo.Entity.user;
import com.coforge.demo.Service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/login")
    public ResponseEntity<String> loginPage() {
        return ResponseEntity.ok("Login Page");
    }

    @PostMapping("/login")
    public ResponseEntity<String> processLogin(@RequestBody user loginRequest, HttpSession session1) {
        if (userService.validateUser(loginRequest.getEmail(), loginRequest.getPassword())) {
            session1.setAttribute("user", loginRequest.getEmail());
            System.out.println("email:" + loginRequest.getEmail());

            return ResponseEntity.ok("Login successful");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid Username or Password");
        }
    }

    @GetMapping("/createAccount")
    public ResponseEntity<String> showCreateAccountPage() {
        return ResponseEntity.ok("Create Account Page");
    }

    @PostMapping("/createAccount")
    public ResponseEntity<String> createAccount(@RequestBody user createRequest) {
        String result = userService.createAccount(createRequest.getUsername(), createRequest.getPassword(), createRequest.getFirstName(), createRequest.getLastName(), createRequest.getEmail(), createRequest.getConfirmPassword(), createRequest.getContactNo());
        if (result.equals("Account created successfully!")) {
            return ResponseEntity.status(HttpStatus.CREATED).body(result);
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);
        }
    }

    @GetMapping("/forgot-password")
    public ResponseEntity<String> showForgotPasswordPage() {
        return ResponseEntity.ok("Forgot Password Page");
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<String> resetPassword(@RequestBody user resetPasswordRequest) {
        String result = userService.resetPassword(resetPasswordRequest.getEmail(), resetPasswordRequest.getPassword());
        return ResponseEntity.ok(result);
    }
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login?logout";
    }
}